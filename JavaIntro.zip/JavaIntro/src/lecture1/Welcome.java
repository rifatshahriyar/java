package lecture1;

public class Welcome {
    public static void main(String[] args) {
        System.out.println("Hello Java");
        System.out.printf("I like %s\n", "Java");
        String strDepartment = "CSE";
        System.out.print("We study in " + strDepartment + "\n");
    } // end method main
} // end class Welcome ‐ NOTE: no semicolon is required here
